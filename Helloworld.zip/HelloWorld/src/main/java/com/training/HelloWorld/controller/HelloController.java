package com.training.HelloWorld.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.training.HelloWorld.Book;

@Controller
public class HelloController {
	@Autowired
	Book book;
	
	@RequestMapping("/")	
	public String index() {
		return "index";
	}
	
	@PostMapping("/hello")
	public String sayHello(@RequestParam("name") String name, Model model) {
		model.addAttribute("name", name);
		return "hello";
	}
	
	@RequestMapping("/form")
	public String form(Model model) {
		book.setAuthor("Balaguruswamy");
		book.setId(1);
		book.setName("C++");
		book.setPrice(100d);
		
		model.addAttribute("book", book);
		
		return "form";
	}
	
	
//	@RequestMapping(value = "/a", produces= {"application/JSON"})
//	@ResponseBody
//	String ret() {
//		return "produces attribute";
//		
//	}

}
