package com.training.HelloWorld.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FormController {
//	@RequestMapping("/formSubmit") 
//	public String formsubmit(@RequestParam() String firstName, @RequestParam() String lastName) {
//		return "<html><body><h1>Hi " + firstName + " " + lastName + "<h2></body></html>";
//		
//	}
	@RequestMapping("/formSubmit")
	public String formsubmit(@RequestParam() Map<String,String> map) {
		String responseData = "<html><body>";
		for(Map.Entry<String, String> x : map.entrySet()) {
			responseData += x.getKey() + " : " + x.getValue() + "<br/>";
		}
		
		System.out.println(responseData);
		
		return responseData + "</body></html>";
	}

}
	