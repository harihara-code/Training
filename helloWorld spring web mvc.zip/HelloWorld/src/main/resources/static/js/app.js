function validate() {
	var name = document.getElementById("name").value;
	if(name == '') {
		alert('please enter a valid name.');
		return false;
	} else {
		return true;
	}
}