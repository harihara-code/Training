function fillformwithjsondata() {
	var item = data;
	
	$('#firstName').val(item.firstname);
//	$('#lastName').val(item.lastname);
	$('#address').val(item.address);
	$('#email').val(item.email);
	$('#mobileno').val(item.mobileno);
 
	if(item.gender == 'male') {
		$('#male').attr('checked', true);
	}
	else {
		$('#female').attr('checked', true);
	}
	
	$('#age').val(item.age);
	
	$('#selectCountry option').each(function() {
		if($(this).val() == item.country) {
			$(this).attr('selected', true);
		}
	});
	
	updateStates();
	
	$('#selectState option').each(function() {
		if($(this).val() == item.state) {
			$(this).attr('selected', true);
		}
	});
	
	$('.course').each(function(){
		for(x in item.courses) {
			if($(this).val() == item.courses[x]) {
				$(this).attr("checked", true);
			}
		}
	});
}

// form validation method
function validateForm() {
	var userForm = $('#userForm');
	var success = false;
	
	// validate first name 
	if(userForm.find('#firstName').val() == '') {
		alert('First Name field empty please fill that');
	}
	
	// validate last name	
	else if(userForm.find('#lastName').val() == '') {
		alert('Last Name field empty please fill that');
	}
	
	// validate address	
	else if(userForm.find('#address').val() == '') {
		alert('Address field empty please fill that');
	} 
	
	
	// validate mobile no	
	else if(userForm.find('#mobileno').val() == '') {
		alert('Mobile No field empty please fill that');
	}
	
	// validate email	
	else if(userForm.find('#email').val() == '') {
		alert('email field empty please fill that');
	}
	// validate gender	
	else if(!userForm.find('#male').prop('checked') && !userForm.find('#female').prop('checked')) {
		alert("Gender not selected");
	}
	
	// validate age	
	else if(userForm.find('#age').val() == '') {
		alert('Age field empty please fill that');
	} 
	
	// validate courses (user need to select atleast one course)
	else if(! isAnyCourseSelected()) {
		alert('No course selected please select atleast one course');
	} 
	
	else {
		success = true;
	}
	return success;
}


function isAnyCourseSelected() {
	var courseSelected;
	
	$('.course').each(function(){
		if($(this).prop('checked')) {
			courseSelected = true;
		}
	});
	
	return courseSelected;
}

//formSubmit() updated with jquery
function formSubmit() {
	var userForm = $('form#userForm');
	
	var data = "Form Submitted !!\n";
	
	data += 'First Name - ' + userForm.find('#firstName').val() +'\n'
			+'Last Name - ' + userForm.find('#lastName').val() +'\n'
			+'Address - ' + userForm.find('#address').val() +'\n'
			+'Email - ' + userForm.find('#email').val() +'\n'
			+'Mobile - ' + userForm.find('#mobileno').val() +'\n'
			+'Gender - ' + ($('#userForm #male').prop('checked') ? "male" : "female") +'\n'
			+'Age - ' + userForm.find('#age').val() +'\n' 
			+'Country - ' + userForm.find('#selectCountry').val() +'\n'
			+'States - ' + userForm.find('#selectState').val()+'\n';
	
	data += 'Selected Courses :';
	
	$('.course').each(function() {
		if($(this).prop('checked')) {
			data += $(this).val() + ' ';	
		}
	});

	alert(data);	
}

function updateStates() {
	var states = {
			"us" : "<option value=\"texas\">Texas</option><option value=\"california\">California</option><option value=\"kansas\">Kansas</option><option value=\"sanfrancisco\">Sanfrancisco</option><option value=\"newmexico\">New_Mexico</option>",
			"eng" : "<option value=\"wales\">Wales</option><option value=\"london\">London</option>",
			"sfa" : "<option value=\"westerncape\">Western Cape</option><option value=\"easterncape\">EasternCape</option>",
			"ind":"<option value=\"tamilnadu\">Tamilnadu</option><option value=\"kerala\">Kerala</option><option value=\"karnataka\">Karnataka</option><option value=\"telangana\">Telangana</option>",
			"aus" : "<option value=\"melbourne\">Melbourne</option><option value=\"sydney\">Sydney</option>"
	}
	var country = $("#selectCountry").val();
	$("#selectState").html(states[country]);
}



function resetForm() {
	$('input[type="text"]').val('');
	$('textarea').val('');
	$('option').removeAttr('selected');
	
// Country field reseted to default United_States_Of_America so we need to update the states with us states  
	updateStates();
	
	$('input[type="radio"]').removeAttr('checked');
	$('input[type="checkbox"]').removeAttr('checked');
}