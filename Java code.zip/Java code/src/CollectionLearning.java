import java.util.TreeSet;

public class CollectionLearning {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("C");
		ts.add("Bba");
		ts.add("Bba");
		ts.add("E");
		ts.add("F");
		
		MyUtility util = new MyUtility();
		util.print(ts.subSet("Bba", "F"));
		
		
		
	}

}
