import java.io.IOException;

public class ExceptionHandling {
	public static void main(String[] args) {
		MyUtility util = new MyUtility();
		
		try {
			throw new MyException("hari");
		} catch(MyException m) {
			util.print(m);
		} finally {
			util.print("finally block");
		}
//Arithmetic exception
//		try {
//			//int value = 100/0;
//			throw new IOException("Sorry device error");
//		} catch(ArithmeticException e) {
//			
//			util.print(e);
//			int d = 50/0;
//		} finally {
//			util.print("inside finally block");
//		} 
		
//		throw new ArithmeticException("not valid");
//		new ExceptionHandling().c();
	
	//Unchecked exception propagation
//	void a() {
//		int b = 10/0;
//	}
//	void b() {
//		a();
//	}
//	void c() {
//		try {
//			b();
//		} catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//			
//			
//		}
//	}
	
//	//checked exception propagation
//	void a() {
//		throw new IOException("device error");
//	}
//	void b() {
//		a();
//	}
//	void c() {
//		try {
//			b();
//		} catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//			
//			
//		}
//	}
		
	//	System.gc();
	}
	
	public void finalize() {
		System.out.println("Garbage collection called");
	}
}



class MyException extends Exception {
	MyException(String s) {
		super(s);
	}
//	MyException() {
//		
//	}
//	
	
}
