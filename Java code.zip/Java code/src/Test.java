import java.util.*;

public class Test {
	public static void main(String[] args) throws Exception {
////		System.out.println("test");
//		Map<Integer, String> map1 = new HashMap<Integer, String>();
//		map1.put(1,"person1");
//		map1.put(2,"person2");
//		map1.put(3,"person3");
////		Iterator mapiter = map1.keySet().iterator();
////		System.out.println("Keys in map are :");
////		while(mapiter.hasNext()) {
////			System.out.println(mapiter.next());
////		}
////		Iterator mapiter = map1.keySet().iterator();
////		System.out.println("Keys in map are :");
////		while(mapiter.hasNext()) {
////			Object key = mapiter.next();
////			System.out.println("Key : " + key + " && Value : " + map1.get(key));
////			
////		}
		MyUtility util = new MyUtility();
//		//util.printMapValues(map1);
////		Iterator mapValues = map1.values().iterator();
////		while(mapValues.hasNext()) {
////			System.out.println(mapValues.next());
////		}
//		util.printMapKeys(map1);
		
//		byte a = 127;
//		util.print(a);
//		int i = 0;
//		for(;i < 128;i++) {
//			char x = (char) i;
//			util.print(x);
//		}
////		
//		Double object = new Double("2.4");
//        int a = object.intValue();
//        byte b = object.byteValue();
//        float d = object.floatValue();
//        double c = object.doubleValue();
//        
//        util.print("integer" + a);
//        util.print("byte" + b);
//        util.print("float" + c);
//        util.print("double" + d);
//        util.print(a + b + d + c);
//        System.out.println(a + b + c + d );
//		
//		  int x = 1;
//		  char c = (char) x;
		
//		double d = 2.27832;
//		int x = (int) d;
//		util.print(x + 'A');
		
//		boolean h = false;
//		util.print(h);
//
		
//	       int i = 132;
//	       short s = 15;
//		   byte b = (byte) i;
//		   int x = b + s;
//		   util.print(b);
//		   System.out.println("Value of x is " + x);
//		 	long l = 22;
//	        int e = (int)(l + 3);
//	        boolean m = l < e;
//	        float o = 12.5f;
//	        double n = o * 2;
//	        System.out.println(l + "e" + m + "o" + n);
//		int i = 0;
//		while(true) {
//			if(i > 1000) {
//				util.print("false");
//				break;
//			}
//			i++;
//			util.print(i + " true");
//		}
		
//		int[] a = new int[] {1,2,3,4,5,6,7,8,9,10};
//		util.print(Arrays.toString(a));
		//Java 5 enhanced forloop to iterate the elements in the array or collection
//		for(int x : a) {
//			if(x == 10) 
//				x = 5;
//			util.print(x);
//		}
//		util.print(Arrays.toString(a));
//		util.print("MAX VALUE - " + Integer.MAX_VALUE);
//		util.print("MIN VALUE - " + Integer.MIN_VALUE);
//		List<String> list = new ArrayList<>();
//		list.add("1");
//		list.add(true + "");
//		
//		for(String x : list)
//			util.print(x);
//		Map<Integer, String> mapHttpErrors = new HashMap<>();
//		 
//		mapHttpErrors.put(200, "OK");
//		mapHttpErrors.put(303, "See Other");
//		mapHttpErrors.put(404, "Not Found");
//		mapHttpErrors.put(500, "Internal Server Error");
//		 
//		System.out.println(mapHttpErrors);
		
		
//		Map<Integer, Integer> map = new HashMap<>();
//		map.put(1, 10);
//		map.put(2, 20);
//		map.put(3, 30);
//		map.put(4, 40);
//		map.put(5, 50);
//		util.print(map);
//		util.print(map.remove(2,20));
//		util.print(map.isEmpty());
//		util.print(map.size());
//		map.clear();
//		util.print(map.isEmpty());
		
//		Map<String,String[]> map = new HashMap<>();
//		map.put("TN", new String[]{"Chennai", "Tanjore", "Kodambakkam","Guindy","Vandalur"});
//		map.put("Kerala", new String[]{"Cochin","Chenganur"});
//		map.put("Karnataka", new String[] {"Mangalore","Bangalore"});
//		
//		for(Map.Entry<String, String[]> x : map.entrySet()) {
//			String state = x.getKey();
////			util.print(state);
//			util.print("state : " + state);
//			for(String city : x.getValue()) {
//				if(!city.equals("Chennai"))
//					util.print(city);
//			}
//		}
//		
//		
//		List<String> code = new ArrayList<>();
//		code.add("001");
//		code.add("004");
//		code.add("005");
//		code.add("002");
//		code.add("003");
//		util.print(code);
//		Collections.sort(code);
//		util.print(code);
//		
//		
//		PriorityQueue<String> names = new PriorityQueue<>();
//		names.add("Hariharan");
//		names.add("Rahul");
//		names.add("Leena");
//		names.add("Sridivya");
//		
//		util.print(names.poll());
//		util.print(names);
//		
//		try {
//			util.print("Inside try block");
//			throw new NullPointerException();
//		} catch(ArrayIndexOutOfBoundsException ex) {
//			util.print("Inside catch block");
//		} finally {
//			util.print("Inside finally block");
//		}
//		
//		Map<String,Integer> map = new HashMap<>();
//		map.put("hari",1);
//		map.put("haran",2);
//		
//		for(String key : map.keySet()) {
//			System.out.println(map.get(key));
//			
//		}
		
//		String str = "hariharan";
//		util.print(str.substring(0,10));
		
//		char[] bucket = "Hello World".toCharArray();
//		util.print(bucket[0]);'
		
		
		
		
		
		
		
	}
}
