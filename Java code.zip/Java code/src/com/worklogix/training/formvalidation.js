//$(function(){
//	$('form[name="PersonalDetails"]').validate({
//		rules : {
//			name : "required"
//		},
//		messages : {
//			name : "Name required field"
//		},
//		submitHandler: function(form) {
//		      form.submit();
//		    }
//	});
//});