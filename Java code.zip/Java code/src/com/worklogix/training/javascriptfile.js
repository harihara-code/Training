function formsubmit() {
//	alert("Form Submitted. Thank you !!");
}

//var colorIndex = 0;
//setInterval(function change() {  
//	var doc = document.getElementById("background");  
//	var color =[ "Grey", "#E5C2F0", "#83A2EE", "#D4F9C9"];  
//	if(colorIndex == 3) {
//		colorIndex = 0;
//	} else {
//		colorIndex += 1;
//	}
//	doc.style.backgroundColor = color[colorIndex];
//	}, 5000);
//testing jquery working
$(function(){console.log('hi world')});

$(document).ready(function(){
//	$('input[type="button"][value="test"]').click(function(){
//	// checking for empty text fields
//		$('input[type="text"]').each(function(){
//			if($(this).val() == '') {
//				alert("Some fields having missing values please fill all");
//				return false;
//			}
//		});
//		var genderChoosen = false;
//	// checking for user not selecting gender
//		$('input[type="radio"]').each(function() {
//			if($(this).prop("checked")) {
//				console.log("checked");
//				genderChoosen = true;
//			} 
//			
////			console.log($(this).attr("checked"));
//		});
//		
//s		if(!genderChoosen) {
//			alert("please choose gender");
//		}
//		
//	
//		
//	});
	
	$('input#dob').datepicker();
	$('input[type="radio"]').checkboxradio();
	$('select.singleselect').selectmenu();
	$('input[type="checkbox"]').checkboxradio();
	$('img').draggable();
	
	
	
	//$('select#language').multiselect();
	

	
});


