$(function(){
	$('input#test').click(function(){
		$('div#content').dialog('open');
	});
	$('div#content').dialog({
		autoOpen:false
	});
	
});


