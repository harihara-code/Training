import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.worklogix.training.Student;

public class Testjava {
	public static void main(String[] args) {
		List<Student> studentList = new ArrayList<Student>();
		Student student = new Student();
		student.setId(1);
		student.setEmail("01@gmail.com");
		studentList.add(student);
		
		student = new Student();
		student.setId(2);
		student.setEmail("02@gmail.com");
		studentList.add(student);
		
		student = new Student();
		student.setId(3);
		student.setEmail("03@gmail.com");
		studentList.add(student);
		
	    List<String> removeEmailList = new ArrayList<String>();
	    removeEmailList.add("01@gmail.com");
	    removeEmailList.add("02@gmail.com");
	    
	    //System.out.println(studentList);
	    System.out.println("Student Details:	 "+studentList.toString());
	    
	    Map<Integer,String> map = new HashMap<>();
	    
	    Iterator<Student> studentIter = studentList.iterator();
	    
	    // Removing student object based on remove Email list
	    while(studentIter.hasNext()) {
	    	Student x = studentIter.next();
	    	//deleting student object
	    	if(removeEmailList.contains(x.getEmail())) {
	    		//System.out.println("Email matching so removing this object");
	    		studentIter.remove();
	    	} 
	    }
	    
	    // Printing remaining student objects after removing
	    System.out.println("Remaining Students after removing based on emails");
	    
	    for(Map.Entry<Integer, String> x : map.entrySet()) {
	    	System.out.println("Student id : " + x.getKey() + " & email : " + x.getValue());
	    }
	    
	    
		
	}
}
