import java.util.*;

class Book {
	String name;
	int id;
	Book(int id, String name){
		this.id = id;
		this.name = name;
	}
}
public class Userkey {
	public static void main(String[] args) {
		Map<Book,Integer> bookMap = new HashMap<>();
		Book book1 = new Book(1, "Book One");
		Book book2 = new Book(2, "Book Two");
		Book book3 = new Book(3, "Book Three");
		
		bookMap.put(book1, 10000);
		bookMap.put(book2, 20000);
		bookMap.put(book3, 30000);
		book1.name = "NameNotDefined";
		for(Book b : bookMap.keySet()) {
			System.out.println(b.name);
		}
	}
}
