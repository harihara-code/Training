import java.util.*;


public class MyUtility {
	void printMapValues(Map map) {
		Iterator mapValues = map.values().iterator();
		while(mapValues.hasNext()) {
			System.out.println(mapValues.next());
		}
	}
	
	void printMapKeys(Map map) {
		Iterator mapKeys = map.keySet().iterator();
		while(mapKeys.hasNext()) {
			System.out.println(mapKeys.next());
		}
	}
	
	void print(Object s) {
		System.out.println(s);
	};
}
